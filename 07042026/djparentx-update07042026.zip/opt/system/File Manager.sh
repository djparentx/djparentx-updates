#!/bin/bash
exec sudo /opt/dingux/DinguxCommander